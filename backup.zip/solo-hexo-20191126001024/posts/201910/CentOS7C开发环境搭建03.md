title: CentOS 7 C++开发环境搭建(03)
date: '2019-10-28 20:30:26'
updated: '2019-11-25 23:25:30'
tags: [autoconf, automake, gdb, cmake]
permalink: /articles/2019/10/28/1572265826888.html
---
### gcc安装
> 系统默认安装的gcc版本为4.8，在更低版本的CentOS上版本更低，导致很多C、C++新特性不能使用，而我又比较喜欢新东西，所以我就编译安装最新的gcc9.2.0
#### 01依赖项目安装
```shell
# 安装bison,解决编译中会提示 “WARNING: ‘bison’ is missing on your system.”
yum install bison
# 安装texinfo,解决编译中会提示“WARNING: ‘makeinfo’ is missing on your system”
yum install texinfo
```
#### 02安装autoconf
```shell
# 下载autoconf
wget http://ftp.gnu.org/gnu/autoconf/autoconf-2.69.tar.gz
tar xvf autoconf-2.69.tar.gz
cd autoconf-2.69
./configure --prefix=/usr/local/autoconf
make && make install
```
#### 03安装automake
```shell
# 首先需要安装perl环境
yum install perl perl-devel
yum install perl-Module-Install.noarch
# 安装包解决：找不到EXTERN.h文件的问题
yum install perl-ExtUtils-Embed
yum install perl-Thread-Queue

wget http://ftp.gnu.org/gnu/automake/automake-1.16.tar.gz
tar xvf automake-1.16.tar.gz
cd automake-1.16
./configure --prefix=/usr/local/autoconf
#修改Makefile 查找 /doc\/automake\-$(APIVERSION)
#doc/automake-$(APIVERSION).1: $(automake_script) lib/Automake/Config.pm
#    $(update_mans) automake-$(APIVERSION) --no-discard-stderr
#(automake-1.15版本 3686行)加上--no-discard-stderr
#(automake-1.16版本 3694行)加上--no-discard-stderr
make && make install
```
#### 安装gcc
> 我虚拟机电脑2G内存时编译报错，网上说增加交换空间，我懒得划分，直接就划分4内存了
```shell
# 下载gcc9.2
wget http://ftp.tsukuba.wide.ad.jp/software/gcc/releases/gcc-9.2.0/gcc-9.2.0.tar.gz
tar -xvf gcc-9.2.0.tar.gz
cd gcc-9.2.0
sh contrib/download_prerequisites
mkdir build && cd build
# 考虑到默认版本为4.8，可能遇到兼容性问题，所以9.2的安装目录自己换一个目录
../configure --enable-checking=release --enable-languages=c,c++ --disable-multilib --prefix=/data/app
make && make install
```

#### 安装gdb
```shell
wget http://ftp.gnu.org/gnu/gdb/gdb-8.3.tar.gz
tar xvf gdb-8.3.tar.gz
cd gdb-8.3
./configure --prefix=/data/app/
make && make install
```
#### 安装cmake
```shell
git clone https://github.com/Kitware/CMake.git
cd Cmake
./configure --prefix=/data/app
make && make install
```
#### 安装ragel
```shell
# 安装ragel之前，需要安装colm
wget http://www.colm.net/files/colm/colm-0.13.0.7.tar.gz
tar xvf colm-0.13.0.7.tar.gz
cd colm-0.13.0.7
./configure --prefix=/data/app
make && make install

# 安装ragel
wget http://www.colm.net/files/ragel/ragel-7.0.0.12.tar.gz
tar xvf ragel-7.0.0.12.tar.gz
cd ragel-7.0.0.12
./configure --prefix=/data/app
make && make install
```
#### 安装protobuf
```shell
# 安装protobu依赖
sudo yum install autoconf
sudo yum install automake
sudo yum install libtool libsysfs
sudo yum install make
sudo yum install g++
sudo yum install unzip

git clone https://github.com/protocolbuffers/protobuf.git
cd protobuf
git submodule update --init --recursive
./autogen.sh
# 会报如下错误，需要编译安装libtool
+ mkdir -p third_party/googletest/m4
+ autoreconf -f -i -Wall,no-obsolete
configure.ac:30: error: possibly undefined macro: AC_PROG_LIBTOOL
      If this token and others are legitimate, please use m4_pattern_allow.
      See the Autoconf documentation.
autoreconf: /data/app/bin/autoconf failed with exit status: 1
# 
wget http://ftp.gnu.org/gnu/libtool/libtool-2.4.6.tar.gz
tar xvf libtool-2.4.6.tar.gz
cd libtool-2.4.6
./configure --prefix=/data/app
make && make install
```
#### 安装perl
```shell
wget https://www.cpan.org/src/5.0/perl-5.30.0.tar.gz
tar xvf perl-5.30.0.tar.gz
cd perl-5.30.0
./Configure -des -Dprefix=/data/app
make
make test
make install
```

#### 配置环境变量
```shell
vim /etc/profile
# 载文件末尾添加以下内容

# 可执行文件路径
export PATH=/data/app/bin:/data/app/sbin:$PATH

# 动态链接库
LD_LIBRARY_PATH=/data/app/lib:/data/app/lib64:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

# 找到静态库的路径
LIBRARY_PATH=/data/app/lib:/data/app/lib64:$LIBRARY_PATH:
export LIBRARY_PATH

# gcc找到头文件的路径
C_INCLUDE_PATH=/data/app/include:$C_INCLUDE_PATH
export C_INCLUDE_PATH

# g++找到头文件的路径
CPLUS_INCLUDE_PATH=/data/app/include:$CPLUS_INCLUDE_PATH
export CPLUS_INCLUDE_PATH

# 为ctags添加别名
alias vctags="ctags -R --c++-kinds=+p --fields=+iaS --extra=+q"

# 退出vim,执行命令
source /etc/profile
```
```shell
# vim打开/etc/ld.so.conf
vim /etc/ld.so.conf
# 添加自己的库目录

# 更新/etc/ld.so.cache文件
/sbin/ldconfig
````
