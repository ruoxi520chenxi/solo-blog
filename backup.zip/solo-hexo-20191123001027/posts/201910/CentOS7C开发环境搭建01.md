title: CentOS 7 C++开发环境搭建(01)
date: '2019-10-24 13:56:14'
updated: '2019-10-30 20:23:50'
tags: [CentOS7, yum源, ohmyzsh, c++开发环境]
permalink: /articles/2019/10/24/1571896574570.html
---
### 更换官方yum源为国内镜像yum源

#### 安装依赖项
```shell
sudo yum install wget
sudo yum install curl 
```

#### 备份默认的yum源  
```shell  
sudo mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bak  
```

#### 使用阿里yum源  
```shell
cd /etc/yum.repos.d

# 使用wget下载阿里源
sudo wget -nc http://mirrors.aliyun.com/repo/Centos-7.repo
# 使用阿里yum源  
sudo mv CentOS-7.repo CentOS-Base.repo

# 使用curl下载阿里源
curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
```

#### 使用清华yum源
```shell
# 因为网上没找到清华的源文件，所以自己手动输入吧
vi /etc/yum.repos.d/CentOS-Base.repo

# CentOS-Base.repo
#
# The mirror system uses the connecting IP address of the client and the
# update status of each mirror to pick mirrors that are updated to and
# geographically close to the client.  You should use this for CentOS updates
# unless you are manually picking other mirrors.
#
# If the mirrorlist= does not work for you, as a fall back you can try the
# remarked out baseurl= line instead.
#
#

[base]
name=CentOS-$releasever - Base
baseurl=https://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/os/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=os
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7

#released updates
[updates]
name=CentOS-$releasever - Updates
baseurl=https://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/updates/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=updates
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7

#additional packages that may be useful
[extras]
name=CentOS-$releasever - Extras
baseurl=https://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/extras/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=extras
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7

#additional packages that extend functionality of existing packages
[centosplus]
name=CentOS-$releasever - Plus
baseurl=https://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/centosplus/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=centosplus
gpgcheck=1
enabled=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
```

#### 使用网易yum源
```shell
# 使用wget下载网易yum源
sudo wget -nc http://mirrors.163.com/.help/CentOS7-Base-163.repo
# 使用网易yum源  
sudo mv CentOS7-Base-163.repo CentOS-Base.repo

# 使用curl下载网易yum源
curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.163.com/.help/CentOS7-Base-163.repo
```

####  更新本地yum缓存
```shell
# 清除yum缓存
sudo yum clean all  

# 更新列表  
sudo yum list  

# 缓存yum包信息到本机，提高搜索速度  
sudo yum makecache
```

#### 升级系统或者升级包
```shell
# 升级所有包同时也升级软件和系统内核
yum update
# 只升级所有包，不升级软件和系统内核
yum upgrade
```

#### 删除更新内核后的旧的内核
```shell
# 查询当前使用的系统
uname -a
# 查看当前系统所有的内核
rpm -qa | grep kernel
# 移除老版本的内核，不要删除当前正在使用的内核
yum remove 要删除的内核
# 重新编译引导
grub2-mkconfig -o /boot/grub2/grub.cfg
# 重启
init 6
```

### 安装oh my zsh
#### 01安装zsh
```shell
# 安装zsh
yum install zsh

# 更改当前用户的默认shell
chsh -s /bin/zsh

# 重启主机,root用户可以不用重启
reboot

# 查看当前正在使用的shell
echo $SHELL

# 查看当前有哪些shell包
cat /etc/shells
```

#### 02安装oh my zsh
```shell
# 任选一种安装方式即可
# 01手动安装
git clone git://github.com/robbyrussell/oh-my-zsh.git ~/.oh-my-zsh
# 复制.zshrc配置文件
cp ~/.oh-my-zsh/templates/zshrc.zsh-template ~/.zshrc

# 02使用curl自动安装
curl -L https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh | sh

# 03使用wget自动安装
wget https://github.com/robbyrussell/oh-my-zsh/raw/master/tools/install.sh -O - | sh
```

#### 03常用配置
```shell
# oh my zsh主题文件
ls ~/.oh-my-zsh/themes

# 安装语法高亮插件
cd ~/.oh-my-zsh/custom/plugins && git clone git://github.com/zsh-users/zsh-syntax-highlighting.git
# 配置文件启用插件
vim ~/.zshrc
# 找到plugins=(git)这一行,找"plugins"关键字
# 编辑这一行代码,添加zsh-syntax-highlighting
# 如启用多个插件,请以空格隔开
plugins=(zsh-syntax-highlighting)
# 更新资源
source ~/.zshrc
```
