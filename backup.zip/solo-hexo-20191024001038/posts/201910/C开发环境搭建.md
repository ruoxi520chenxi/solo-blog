title: C++开发环境搭建
date: '2019-10-22 12:30:04'
updated: '2019-10-22 13:41:32'
tags: [ohmyzsh, 开发环境]
permalink: /articles/2019/10/22/1571718604032.html
---
### 安装oh my zsh
> 我的系统环境为CentOS7.6
#### 01安装zsh
```shell
# 安装zsh
yum install zsh

# 更改当前用户的默认shell
chsh -s /bin/zsh

# 重启主机,root用户可以不用重启
reboot

# 查看当前正在使用的shell
echo $SHELL

# 查看当前有哪些shell包
cat /etc/shells
```

#### 02安装oh my zsh
```shell
# 任选一种安装方式即可
# 01手动安装
git clone git://github.com/robbyrussell/oh-my-zsh.git ~/.oh-my-zsh
# 复制.zshrc配置文件
cp ~/.oh-my-zsh/templates/zshrc.zsh-template ~/.zshrc

# 02使用curl自动安装
curl -L https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh | sh

# 03使用wget自动安装
wget https://github.com/robbyrussell/oh-my-zsh/raw/master/tools/install.sh -O - | sh
```

#### 03 常用配置
```shell
# oh my zsh主题文件
ls ~/.oh-my-zsh/themes

# 安装语法高亮插件
cd ~/.oh-my-zsh/custom/plugins && git clone git://github.com/zsh-users/zsh-syntax-highlighting.git
# 配置文件启用插件
vim ~/.zshrc
# 找到plugins=(git)这一行,找"plugins"关键字
# 编辑这一行代码,添加zsh-syntax-highlighting
# 如启用多个插件,请以空格隔开
plugins=(zsh-syntax-highlighting)
# 更新资源
source ~/.zshrc
```
