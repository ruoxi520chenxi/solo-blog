title: Linux上根据对应sig文件校验文件的完整性
date: '2019-10-31 14:42:35'
updated: '2019-10-31 14:42:35'
tags: [签名验证, sig文件]
permalink: /articles/2019/10/31/1572504155509.html
---
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在 Linux 的软件下载安装中，经常看到有与文件相同名字但是以.sig 结尾的文件，最开始的时候，我并没有怎么去在意这个文件是干嘛的，知道后来我遇到了下载下来的文件解压出问题了，然后就在想在 windwows 下载文件的时候大部分都提供了 sha、md5 类似的校验码，但是在 Linux 上下载文件的时候很少看到，所以我就去网上搜了下看这个 sig 文件到底是干嘛的，原来才发现这个**.sig 文件是一个签名文件，用于校验文件的完整性**
#### 利用gpg命令验证数据完整性
```shell
# gpg命令验证数据完整性
~: gpg --verify gdb-8.3.tar.gz.sig gdb-8.3.tar.gz
gpg: 已创建目录‘/home/darren/.gnupg’
gpg: 新的配置文件‘/home/darren/.gnupg/gpg.conf’已建立
gpg: 警告：在‘/home/darren/.gnupg/gpg.conf’里的选项于此次运行期间未被使用
gpg: 钥匙环‘/home/darren/.gnupg/pubring.gpg’已建立
gpg: 于 2019年05月12日 星期日 02时44分55秒 CST 创建的签名，使用 DSA，钥匙号 FF325CF3
gpg: 无法检查签名：没有公钥

# 导入公钥
~: gpg --recv-keys FF325CF3
gpg: 钥匙环‘/home/darren/.gnupg/secring.gpg’已建立
gpg: 下载密钥‘FF325CF3’，从 hkp 服务器 keys.gnupg.net
gpg: /home/darren/.gnupg/trustdb.gpg：建立了信任度数据库
gpg: 密钥 FF325CF3：公钥“Joel Brobecker <brobecker@adacore.com>”已导入
gpg: 没有找到任何绝对信任的密钥
gpg: 合计被处理的数量：1
gpg:           已导入：1

# 也有可能提示从公钥服务器接收失败：URL已损坏，这时需要手动绑定公钥服务器
~: gpg --recv-keys --keyserver  keys.gnupg.net FF325CF3
gpg: 下载密钥‘FF325CF3’，从 hkp 服务器 keys.gnupg.net
gpg: /home/darren/.gnupg/secring.gpg：建立了信任度数据库
gpg: 密钥 FF325CF3：公钥“Joel Brobecker <brobecker@adacore.com>”已导入
gpg: 没有找到任何绝对信任的密钥
gpg: 合计被处理的数量：1
gpg:               已导入：1  (RSA: 1)

# 再次验证数据的完整性
~: gpg --verify gdb-8.3.tar.gz.sig gdb-8.3.tar.gz
gpg: 于 2019年05月12日 星期日 02时44分55秒 CST 创建的签名，使用 DSA，钥匙号 FF325CF3
gpg: 完好的签名，来自于“Joel Brobecker <brobecker@adacore.com>”
gpg: 警告：这把密钥未经受信任的签名认证！
gpg:       没有证据表明这个签名属于它所声称的持有者。
主钥指纹： F40A DB90 2B24 264A A42E  50BF 92ED B04B FF32 5CF3

# 完好的签名，说明这个文件是完整的
```
