title: CentOS 7 C++开发环境搭建(03)
date: '2019-10-28 20:30:26'
updated: '2019-10-28 20:30:53'
tags: [autoconf, automake]
permalink: /articles/2019/10/28/1572265826888.html
---
### gcc安装
> 系统默认安装的gcc版本还是万年的4.8，导致很多C、C++新特性不能使用，所以我们编译安装最新的gcc9.1.0
#### 01依赖项目安装
```shell
# 安装bison,解决编译中会提示 “WARNING: ‘bison’ is missing on your system.”
yum install bison
# 安装texinfo,解决编译中会提示“WARNING: ‘makeinfo’ is missing on your system”
yum install texinfo
```
#### 02安装autoconf
```shell
# 下载autoconf
wget http://ftp.gnu.org/gnu/autoconf/autoconf-2.69.tar.gz
tar xvf autoconf-2.69.tar.gz
cd autoconf-2.69
./configure --prefix=/usr/local/autoconf
make && make install
```
#### 03安装automake
```shell
# 首先需要安装perl环境
yum install perl perl-devel
yum install perl-Module-Install.noarch
# 安装包解决：找不到EXTERN.h文件的问题
yum install perl-ExtUtils-Embed
yum install perl-Thread-Queue

wget http://ftp.gnu.org/gnu/automake/automake-1.16.tar.gz
tar xvf automake-1.16.tar.gz
cd automake-1.16
./configure --prefix=/usr/local/autoconf
#修改Makefile 查找 /doc\/automake\-$(APIVERSION)
#doc/automake-$(APIVERSION).1: $(automake_script) lib/Automake/Config.pm
#    $(update_mans) automake-$(APIVERSION) --no-discard-stderr
#(automake-1.15版本 3686行)加上--no-discard-stderr
#(automake-1.16版本 3694行)加上--no-discard-stderr
make && make install
```
