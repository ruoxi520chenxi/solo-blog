title: CentOS 7 C++开发环境搭建(02)
date: '2019-10-28 16:06:02'
updated: '2019-10-28 18:28:07'
tags: [autojump, vim, python3, CentOS7]
permalink: /articles/2019/10/28/1572249961944.html
---
### 安装autojump
> autojump可以记录玩家的历史文件夹访问记录，安装后可以使用"j pathname"快速跳转到目录
```shell
# 下载autojump源码
git clone git://github.com/joelthelion/autojump.git

# 安装
cd autojump && ./install.py

# 卸载
cd autojump && ./uninstall.py

# 因为linux下shell启动会读取相应的shell配置文件,所以根据情况将下面一行加入shell配置文件
[[ -s /root/.autojump/etc/profile.d/autojump.sh ]] && source /root/.autojump/etc/profile.d/autojump.sh
autoload -U compinit && compinit -u

#oh my zsh对应的文件 ~/.zshrc
#bash对应的文件 ~/.bashrc
```

### 安装vim
#### 01安装依赖项目
```shell
yum install wget

yum install ncurses-devel

yum install gcc gcc-c++

yum install ctags

# 让vim支持ruby解释器
yum install ruby ruby-devel

# 让vim支持python解释器
yum install python-devel

# 让vim支持perl解释器
yum install perl perl-devel
yum install perl-Module-Install.noarch
# 安装包解决：找不到EXTERN.h文件的问题
yum install perl-ExtUtils-Embed

# 安装lua
yum install libtermcap-devel ncurses-devel libevent-devel readline-devel
# 下载lua源码包
wget http://www.lua.org/ftp/lua-5.3.5.tar.gz
tar xvf lua-5.3.5.tar.gz
cd lua-5.3.5
make linux test
make install
```
#### 03安装Python3
```shell
# 安装依赖项目
yum -y groupinstall "Development tools"
yum -y install zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel

# 下载Python3.8.0源码
wget https://www.python.org/ftp/python/3.8.0/Python-3.8.0.tar.xz
# 解压
tar -xJvf Python-3.8.0.tar.xz
cd Python-3.8.0
mkdir /usr/local/python3
# 指定编译参数
./configure --prefix=/usr/local/python3
# 编译安装
make && make install
# 建立符号链接
ln -s /usr/local/python3/bin/python3 /usr/bin/python3
ln -s /usr/local/python3/bin/pip3 /usr/bin/pip3
```

#### 02安装vim
```shell
# 从github克隆，速度贼慢，推荐直接去官网下载
# 我是直接在我的阿里云主机上git下来，再下载下来的
git clone https://github.com/vim/vim.git

# 清除configure产生的文件
cd vim
make distclean

# 生成Makefile文件
./configure \
--prefix=/usr/local/vim81 \
--with-features=huge \
--enable-multibyte \
--enable-luainterp=yes \
--with-lua-prefix=/usr \
--enable-rubyinterp=yes \
--with-ruby-command=ruby \
--enable-pythoninterp=yes \
--with-python-config-dir=/usr/lib64/python2.7/config \
--enable-python3interp=yes \
--with-python3-config-dir=/usr/local/python3/lib/python3.8/config-3.8-x86_64-linux-gnu \
--enable-perlinterp=yes \
--enable-rubyinterp=yes \
--enable-gui=gtk2 \
--enable-cscope \
--enable-fontset \
--includedir=/usr/lib64/perl5/CORE \
--with-modified-by=Darren \ 
--with-compiledby=Darren \

# 安装(可能会报错)
make && make install

# 如果make install报错
# 可能会报错if_perl.xs:57:20: fatal error: EXTERN.h: No such file or directory
# 搞到这个文件,文件所在目录/usr/lib64/perl5/CORE/
yum makecache
yum update
yum provides "*/EXTERN.h"
```
